ROSHAN SHAH JEWELLERS — DEMO WEBSITE
Files: index.html, collections.html, about.html, contact.html, style.css

This is a client-demo redesign, not the company's official website.
Replace demo collection blocks with the client's approved product photos, catalogue links and final contact/offer details before publishing.
